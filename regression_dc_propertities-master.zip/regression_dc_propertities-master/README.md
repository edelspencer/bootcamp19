# regression_dc_propertities
Regression analysis using sklearn on the DC_Properities.csv dataset
